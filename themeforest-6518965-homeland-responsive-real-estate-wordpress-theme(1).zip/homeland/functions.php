<?php
	/**********************************************
	SET MAXIMUM CONTENT WIDTH
	***********************************************/

	if ( ! isset( $content_width ) ) 
		$content_width = 1920;


	/**********************************************
	INCLUDED FILES
	***********************************************/

	include get_template_directory() . '/includes/mabuc-panel/main.php';
	include get_template_directory() . '/includes/lib/custom-posts.php';
	include get_template_directory() . '/includes/lib/custom-fields.php';
	include get_template_directory() . '/includes/lib/custom-widgets.php';
	include get_template_directory() . '/includes/lib/custom-functions.php';
	include get_template_directory() . '/includes/lib/tgm/activation.php';


	/**********************************************
	REGISTER STYLES AND SCRIPTS
	***********************************************/

	function homeland_script_styles_reg () {
		wp_register_style( 'homeland_style', get_stylesheet_directory_uri() . '/style.css' );	
		wp_register_style( 'homeland_responsive', get_stylesheet_directory_uri() . '/responsive.css' );	
		wp_register_style( 'homeland_bitter', 'http://fonts.googleapis.com/css?family=Bitter:400,700,400italic&subset=latin,latin-ext' );				
		wp_register_style( 'homeland_font-awesome', get_template_directory_uri() . '/includes/font-awesome/css/font-awesome.min.css' );
		wp_register_script( 'homeland_mobile-menu', get_template_directory_uri() . '/js/jquery.mobilemenu.js', array(), '', true );	
		wp_register_script( 'homeland_easing', get_template_directory_uri() . '/js/jquery.easing-1.3.min.js', array(), '', true );	
		wp_register_script( 'homeland_masonry', get_template_directory_uri() . '/js/jquery.masonry.min.js', array(), '', true );		
		wp_register_script( 'homeland_retina', get_template_directory_uri() . '/js/retina.js', array(), '', true );	
		wp_register_script( 'homeland_backstretch', get_template_directory_uri() . '/js/jquery.backstretch.min.js', array(), '', true );
		wp_register_script( 'homeland_validation', get_template_directory_uri() . '/js/jquery.validate.min.js', array(), '', true );
		wp_register_script( 'homeland_tipsy', get_template_directory_uri() . '/js/tipsy/jquery.tipsy.js', array(), '', true );		
		wp_register_script( 'homeland_fitvids', get_template_directory_uri() . '/js/jquery.fitvids.js', array(), '', true );	
		wp_register_script( 'homeland_custom-js', get_template_directory_uri() . '/js/custom.js', array(), '', true );	
		
		
		/*SUPERFISH DROPDOWN MENU*/
		wp_register_style( 'homeland_superfish-style', get_template_directory_uri() . '/js/superfish/superfish.css' );	
		wp_register_script( 'homeland_superfish', get_template_directory_uri() . '/js/superfish/superfish.min.js', array(), '', true );


		/*FLEXSLIDER*/
		wp_register_style( 'homeland_flexslider-style', get_template_directory_uri() . '/js/flexslider/flexslider.css' );		
		wp_register_script( 'homeland_flexslider', get_template_directory_uri() . '/js/flexslider/jquery.flexslider-min.js', array(), '', true );

		/*HTML5 VIDEO PLAYER*/
		wp_register_style( 'homeland_videojs-css', get_template_directory_uri() . '/js/video/video-js.css' );	
		wp_register_script( 'homeland_videojs', get_template_directory_uri() . '/js/video/video.js', array(), '', true );

		/*TOUCHTOUCH*/
		wp_register_style( 'homeland_touch-style', get_template_directory_uri() . '/js/touchTouch/touchTouch.css' );	
		wp_register_script( 'homeland_touch', get_template_directory_uri() . '/js/touchTouch/touchTouch.jquery.js', array(), '', true );	

		/*GOOGLE MAP*/
		wp_register_script( 'homeland_gmap-sensor', 'http://maps.google.com/maps/api/js?sensor=true' );
		wp_register_script( 'homeland_gmap', get_template_directory_uri() . '/js/gmap.js' );

		/*HOVER EFFECT*/
		wp_register_style( 'homeland_hover-style', get_stylesheet_directory_uri() . '/js/hover/component.css' );		
		wp_register_script( 'homeland_hover-modernizr', get_template_directory_uri() . '/js/hover/modernizr.custom.js', array(), '', true );

		/*CAPTION EFFECT*/
		wp_register_style( 'homeland_caption-style', get_stylesheet_directory_uri() . '/js/caption/component.css' );		
		wp_register_script( 'homeland_caption', get_template_directory_uri() . '/js/caption/toucheffects.js', array(), '', true );
		wp_register_script( 'homeland_caption-modernizr', get_template_directory_uri() . '/js/caption/modernizr.custom.js', array(), '', true );

		/*ELASTIC SLIDER*/
		wp_register_style( 'homeland_elastic-style', get_stylesheet_directory_uri() . '/js/elastislide/elastislide.css' );
		wp_register_script( 'homeland_elastic', get_template_directory_uri() . '/js/elastislide/jquery.elastislide.js', array(), '', true );	
		wp_register_script( 'homeland_elastic-custom', get_template_directory_uri() . '/js/elastislide/custom-elastislide.js', array(), '', true );

		/*EXPAND SEARCH*/
		wp_register_style( 'homeland_search-style', get_stylesheet_directory_uri() . '/js/search/component.css' );
		wp_register_script( 'homeland_search', get_template_directory_uri() . '/js/search/uisearch.js', array(), '', true );	
		wp_register_script( 'homeland_search-classie', get_template_directory_uri() . '/js/search/classie.js', array(), '', true );
		wp_register_script( 'homeland_search-modernizr', get_template_directory_uri() . '/js/search/modernizr.custom.js', array(), '', true );

		/*SELECTBOX CUSTOM*/
		wp_register_style( 'homeland_selectbox-style', get_stylesheet_directory_uri() . '/js/selectbox/jquery.selectBox.css' );
		wp_register_script( 'homeland_selectbox', get_template_directory_uri() . '/js/selectbox/jquery.selectBox.min.js', array(), '', true );	

		/*COUNTDOWN*/
		wp_register_script( 'homeland_countdown_plugin', get_template_directory_uri() . '/js/countdown/jquery.plugin.min.js', array(), '', true );
		wp_register_script( 'homeland_countdown', get_template_directory_uri() . '/js/countdown/jquery.countdown.min.js', array(), '', true );

				
		/*ENQUEUE STYLE*/
		wp_enqueue_style( 'homeland_style' );
		wp_enqueue_style( 'homeland_bitter' );
		wp_enqueue_style( 'homeland_font-awesome' );
		wp_enqueue_style( 'homeland_superfish-style' );
		wp_enqueue_style( 'homeland_flexslider-style' );
		wp_enqueue_style( 'homeland_caption-style' );	
		wp_enqueue_style( 'homeland_elastic-style' );
		wp_enqueue_style( 'homeland_hover-style' );
		wp_enqueue_style( 'homeland_search-style' );
		wp_enqueue_style( 'homeland_selectbox-style' );
		wp_enqueue_style( 'homeland_animate-style' );
		
		
		/*ENQUEUE SCRIPT*/
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'homeland_superfish' );
		wp_enqueue_script( 'homeland_easing' );
		wp_enqueue_script( 'homeland_retina' );
		wp_enqueue_script( 'homeland_flexslider' );
		wp_enqueue_script( 'homeland_caption-modernizr' );
		wp_enqueue_script( 'homeland_elastic' );
		wp_enqueue_script( 'homeland_elastic-custom' );
		wp_enqueue_script( 'homeland_search' );
		wp_enqueue_script( 'homeland_search-classie' );
		wp_enqueue_script( 'homeland_search-modernizr' );
		wp_enqueue_script( 'homeland_selectbox' );
		wp_enqueue_script( 'homeland_gmap-sensor' );
		wp_enqueue_script( 'homeland_gmap' );	
		wp_enqueue_script( 'homeland_fitvids' );	
		wp_enqueue_script( 'homeland_animate' );	

		//wp_enqueue_script( 'homeland_caption' );
		//wp_enqueue_script( 'homeland_iconmenu' );
		
		if(is_page_template('template-homepage-gmap.php')) : add_action( 'wp_head', 'homeland_google_map_homepage' ); endif;
		if (is_singular()) wp_enqueue_script( "comment-reply" );
		if(get_option('homeland_bg_type')=="Image") : wp_enqueue_script( 'homeland_backstretch' ); endif;
		if(is_page_template('template-blog-grid.php') || is_page_template('template-blog-fullwidth.php') || is_archive() || is_search()) : 
			wp_enqueue_script( 'homeland_masonry' ); 
		endif;
		if(is_page_template('template-properties-2cols.php') || is_page_template('template-properties-3cols.php') || is_page_template('template-properties-4cols.php') || is_page_template('template-homepage3.php')) : 
			wp_enqueue_script( 'homeland_masonry' );
		endif;
		if(is_singular('homeland_properties')) : 
			wp_enqueue_style( 'homeland_touch-style' );
			wp_enqueue_script( 'homeland_touch' );
			wp_enqueue_script( 'homeland_validation' );
			add_action( 'wp_head', 'homeland_google_map_property' );
		endif;
		if(is_single()) :
			wp_enqueue_style( 'homeland_videojs-css' );	
			wp_enqueue_script( 'homeland_videojs' );
			wp_enqueue_script( 'homeland_tipsy' );
		endif;
		if(is_page_template('template-contact.php')) :
			add_action( 'wp_head', 'homeland_google_map' );
		endif;
		if(is_page_template('template-coming-soon.php')) :
			wp_enqueue_script( 'homeland_countdown_plugin' );
			wp_enqueue_script( 'homeland_countdown' );
		endif;
		if(get_option('homeland_site_layout') != "true") :
			wp_enqueue_style( 'homeland_responsive' );		
			wp_enqueue_script( 'homeland_mobile-menu' );	
		endif;

		wp_enqueue_script( 'homeland_custom-js' );

	}
	add_action( 'wp_enqueue_scripts', 'homeland_script_styles_reg' );


	/**********************************************
	POST THUMBNAIL
	***********************************************/

	if ( function_exists( 'add_theme_support' ) ) { 
		add_theme_support( 'post-thumbnails', array( 'post', 'homeland_properties', 'homeland_testimonial' ) );
		set_post_thumbnail_size( 160, 120, true ); 
		add_image_size( 'homeland_slider', 1920, 664, true );
		add_image_size( 'homeland_property_thumb', 153, 115, true );		
		add_image_size( 'homeland_property_medium', 330, 230, true );
		add_image_size( 'homeland_property_large', 709, 407, true );
		add_image_size( 'homeland_property_2cols', 520, 350, true );
		add_image_size( 'homeland_property_4cols', 240, 230, true );
		add_image_size( 'homeland_news_thumb', 70, 70, true );
		add_image_size( 'homeland_widget_property', 230, 175, true );
		add_image_size( 'homeland_widget_thumb', 50, 50, true );
		add_image_size( 'homeland_header_bg', 1920, 300, true );
		add_image_size( 'homeland_theme_large', 770, 9999 );
		add_image_size( 'homeland_theme_thumb', 100, 100, true );
	}


	/**********************************************
	GOOGLE MAP FOR HOMEPAGE PROPERTIES
	***********************************************/

	function homeland_google_map_homepage() {
		global $post;

		$homeland_home_map_lat = get_option('homeland_home_map_lat');
		$homeland_home_map_lng = get_option('homeland_home_map_lng');
		$homeland_home_map_zoom = get_option('homeland_home_map_zoom');
		?>
		<script type="text/javascript">
			(function($) {
			  	"use strict";
			  	var map;
			   $(document).ready(function(){
			    	map = new GMaps({
				      div: '#map-homepage',
				      lat: <?php echo $homeland_home_map_lat; ?>,
						lng: <?php echo $homeland_home_map_lng; ?>,
						zoom: <?php if($homeland_home_map_zoom!="") : echo $homeland_home_map_zoom; else : echo "8"; endif ?>
			      });		      	

	      		<?php
	      			$args = array( 'post_type' => 'homeland_properties' );
						$wp_query = new WP_Query( $args );	

						while ( $wp_query->have_posts() ) : 
							$wp_query->the_post(); 	

							$homeland_lat = get_post_meta( $post->ID, 'homeland_property_lat', true );
							$homeland_lng = get_post_meta( $post->ID, 'homeland_property_lng', true );
							$homeland_price = get_post_meta( $post->ID, 'homeland_price', true );
							$homeland_price_per = get_post_meta( $post->ID, 'homeland_price_per', true );
							$homeland_property_currency = get_option('homeland_property_currency');

							?>
								map.addMarker({
									lat: <?php echo $homeland_lat; ?>,
									lng: <?php echo $homeland_lng; ?>,
							      itle: '<?php the_title(); ?>',
							      infoWindow: {
								   content: '<div class="marker-window"><a href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ) : the_post_thumbnail('homeland_property_thumb'); endif; ?></a><h6><?php the_title(); ?></h6><?php if(!empty($homeland_price)) : ?><h5><?php echo $homeland_property_currency; echo number_format( $homeland_price ); if(!empty($homeland_price_per)) : echo "/" . $homeland_price_per; endif; ?></h5><?php endif; ?></div>'
								   }
							    });
							<?php
				    	endwhile; 
	      		?>			        
			   });
			})(jQuery);					
		</script>
		<?php
	}


	/**********************************************
	GOOGLE MAP FOR SEARCH RESULTS
	***********************************************/

	function homeland_google_map_search() {
		global $post, $args_wp;
		
		$homeland_home_map_lat = get_option('homeland_home_map_lat');
		$homeland_home_map_lng = get_option('homeland_home_map_lng');
		$homeland_home_map_zoom = get_option('homeland_home_map_zoom');
		?>
		<script type="text/javascript">
			(function($) {
			  	"use strict";
			  	var map;
			   $(document).ready(function(){
			    	map = new GMaps({
				      div: '#map-property',
				      lat: <?php echo $homeland_home_map_lat; ?>,
						lng: <?php echo $homeland_home_map_lng; ?>,
						zoom: <?php if($homeland_home_map_zoom!="") : echo $homeland_home_map_zoom; else : echo "8"; endif ?>
			      });		      	

	      		<?php
	      			$args_map = apply_filters('homeland_advance_search_parameters', $args_wp);
						$wp_query_map = new WP_Query( $args_map );

						while ( $wp_query_map->have_posts() ) : 
							$wp_query_map->the_post(); 	

							$homeland_lat = get_post_meta( $post->ID, 'homeland_property_lat', true );
							$homeland_lng = get_post_meta( $post->ID, 'homeland_property_lng', true );
							$homeland_price = get_post_meta( $post->ID, 'homeland_price', true );
							$homeland_price_per = get_post_meta( $post->ID, 'homeland_price_per', true );
							$homeland_property_currency = get_option('homeland_property_currency');

							?>
								map.addMarker({
									lat: <?php echo $homeland_lat; ?>,
									lng: <?php echo $homeland_lng; ?>,
							      itle: '<?php the_title(); ?>',
							      infoWindow: {
								   content: '<div class="marker-window"><a href="<?php the_permalink(); ?>"><?php if ( has_post_thumbnail() ) : the_post_thumbnail('homeland_property_thumb'); endif; ?></a><h6><?php the_title(); ?></h6><?php if(!empty($homeland_price)) : ?><h5><?php echo $homeland_property_currency; echo number_format( $homeland_price ); if(!empty($homeland_price_per)) : echo "/" . $homeland_price_per; endif; ?></h5><?php endif; ?></div>'
								   }
							    });
							<?php
				    	endwhile; 
	      		?>			        
			   });
			})(jQuery);					
		</script><?php
	}


	/**********************************************
	GOOGLE MAP FOR PROPERTY
	***********************************************/

	function homeland_google_map_property() {
		global $post;

		$homeland_lat = get_post_meta( $post->ID, 'homeland_property_lat', true );
		$homeland_lng = get_post_meta( $post->ID, 'homeland_property_lng', true );
		$homeland_property_map_zoom = get_post_meta( $post->ID, 'homeland_property_map_zoom', true ); 
		?>
		<script type="text/javascript">
			(function($) {
			  	"use strict";
			  	var map;
			   $(document).ready(function(){
			    	map = new GMaps({
				        	div: "#map-property",
				        	lat: <?php echo $homeland_lat; ?>,
							lng: <?php echo $homeland_lng; ?>,
							zoom: <?php if($homeland_property_map_zoom!="") : echo $homeland_property_map_zoom; else : echo "8"; endif ?>
			      	});
			      	map.addMarker({
				        	lat: <?php echo $homeland_lat; ?>,
							lng: <?php echo $homeland_lng; ?>				        
			      	});
			    	});
			})(jQuery);					
		</script>
		<?php
	}


	/**********************************************
	GOOGLE MAP FOR CONTACT US
	***********************************************/

	function homeland_google_map() {
		$homeland_lat = get_option('homeland_map_lat');
		$homeland_lng = get_option('homeland_map_lng');
		$homeland_marker_tip = stripslashes( get_option('homeland_map_marker') );
		$homeland_marker_window = stripslashes( get_option('homeland_map_window') );		
		$homeland_map_zoom = get_option('homeland_map_zoom');		
		?>
		<script type="text/javascript">
			(function($) {
			  	"use strict";
			  	var map;
			   $(document).ready(function(){
			    	map = new GMaps({
			        	div: "#map",
				      lat: <?php echo $homeland_lat; ?>,
						lng: <?php echo $homeland_lng; ?>,
						zoom: <?php if($homeland_map_zoom!="") : echo $homeland_map_zoom; else : echo "8"; endif ?>
			      });
		      	map.addMarker({
			        	lat: <?php echo $homeland_lat; ?>,
						lng: <?php echo $homeland_lng; ?>,
			        	title: "<?php echo $homeland_marker_tip; ?>",
			        	infoWindow: {
				    		content: "<p><?php echo $homeland_marker_window; ?></p>"
				    	}
		      	});
			   });
			})(jQuery);					
		</script>
		<?php
	}


	/**********************************************
	CHANGE DEFAULT LOGIN LOGO & LINK
	***********************************************/

	function homeland_login_image() {
		echo "
			<style>
				body.login #login h1 a {
					background: url('" . get_option( 'homeland_logo' ) . "') center top no-repeat transparent;
					width:100%; height:126px;
				}
			</style>
		";
	}
	function homeland_custom_login_url() { return home_url(); }

	$homeland_logo = get_option('homeland_logo');
	
	if(!empty( $homeland_logo )) : 
		add_action( 'login_head', 'homeland_login_image' );
		add_filter( 'login_headerurl', 'homeland_custom_login_url' ); 
	endif;


	/**********************************************
	CHANGE DEFAULT SITE TITLE 
	***********************************************/

	function homeland_change_default_site_title( $homeland_title ){
		$homeland_screen = get_current_screen();
		if('homeland_properties' == $homeland_screen->post_type) :
			$homeland_title = 'Enter property name';
		elseif('homeland_services' == $homeland_screen->post_type) :
			$homeland_title = 'Enter services name';
		elseif('homeland_testimonial' == $homeland_screen->post_type) :
			$homeland_title = 'Enter name';
		endif;
		return $homeland_title;
	}
	add_filter( 'enter_title_here', 'homeland_change_default_site_title' );


	/**********************************************
	MAIN MENU FALLBACK
	***********************************************/

	function homeland_menu_fallback() {
		$homeland_class = "";
		if(is_front_page()) : $homeland_class="current_page_item"; endif;
		?>
		<div id="dropdown" class="theme-menu clear">
			<ul id="menu-main-nav" class="sf-menu">
				<li class="<?php echo $homeland_class; ?>">
					<a href="<?php echo home_url(); ?>"><?php _e( 'Home', CODEEX_THEME_NAME ); ?></a>
				</li>
				<?php wp_list_pages( 'title_li=&sort_column=menu_order' ); ?>
			</ul>
		</div>
		<?php
	}


	/*****************************************************
	THEME SUPPORTS, EDITOR, POST FORMATS AND BACKGROUND
	*****************************************************/

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-formats', array( 'image', 'video', 'gallery', 'audio' ) );


	/**********************************************
	CUSTOM MENUS
	***********************************************/
	
	add_action( 'init', 'homeland_register_my_menus' );
	function homeland_register_my_menus() {
		register_nav_menus(
			array(
				'primary-menu' => 'Primary Menu',
			)
		);
	}


	/**********************************************
	LANGUAGE LOCALIZATION
	***********************************************/

	define('CODEEX_THEME_NAME', 'homeland_lang');

	add_action('after_setup_theme', 'homeland_language_setup');
	function homeland_language_setup(){		
		load_theme_textdomain(CODEEX_THEME_NAME, get_template_directory() . '/lang');
	}


	/**********************************************
	GET PAGE CUSTOM TITLE
	***********************************************/

	function homeland_get_page_title() {
		global $post, $wp_query, $homeland_page, $homeland_ptitle, $homeland_theme_pages;

		$homeland_search_header = get_option('homeland_search_header');
		$homeland_search_subtitle = get_option('homeland_search_subtitle');
		$homeland_services_single_header = get_option('homeland_services_single_header');
		$homeland_services_single_subtitle = get_option('homeland_services_single_subtitle');
		$homeland_property_single_header = get_option('homeland_property_single_header');
		$homeland_property_single_subtitle = get_option('homeland_property_single_subtitle');
		$homeland_blog_single_header = get_option('homeland_blog_single_header');
		$homeland_blog_single_subtitle = get_option('homeland_blog_single_subtitle');
		$homeland_not_found_header = get_option('homeland_not_found_header');
		$homeland_not_found_subtitle = get_option('homeland_not_found_subtitle');

		if(is_archive()) : ?>
			<h2 class="ptitle">
				<?php 
					if (is_category()) : single_cat_title();
					elseif( is_tag() ) : printf( _e('Posts Tagged: ', CODEEX_THEME_NAME), single_tag_title() ); 
					elseif ( is_day() ) : printf( __( '%s', CODEEX_THEME_NAME ), get_the_date() ); 
					elseif ( is_month() ) : printf( __( '%s', CODEEX_THEME_NAME ), get_the_date( __( 'F Y', 'monthly archives date format', CODEEX_THEME_NAME ) ) ); 
					elseif ( is_year() ) : printf( __( '%s', CODEEX_THEME_NAME ), get_the_date( __( 'Y', 'yearly archives date format', CODEEX_THEME_NAME ) ) ); 
					elseif ( is_tax() ) : echo get_queried_object()->name;
					elseif ( is_author() ) : 
						$homeland_author_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-agents.php'));
						foreach($homeland_author_pages as $homeland_page){
							if(get_post_meta( $homeland_page->ID, "homeland_ptitle", true )!="") : $homeland_ptitle = get_post_meta( $homeland_page->ID, "homeland_ptitle", true ); 
							else : $homeland_ptitle = $homeland_page->post_title; endif;	
							$homeland_subtitle = esc_attr( get_post_meta( $homeland_page->ID, "homeland_subtitle", true ) );
						}
						echo esc_attr( $homeland_ptitle );						
					endif;
				?>
			</h2>
			<?php 
				if( is_author() ) : 
					if(!empty($homeland_subtitle)) : ?>
						<h4 class="subtitle"><label><?php echo stripslashes($homeland_subtitle); ?></label></h4><?php 
					endif;
				elseif( is_category() ) : 
					$homeland_category_id = get_query_var('cat'); 
					$homeland_category_data = get_option("category_$homeland_category_id"); 
					
					if(!empty($homeland_category_data['homeland_subtitle'])) : ?>
						<h4 class="subtitle"><label><?php echo @$homeland_category_data['homeland_subtitle']; ?></label></h4><?php 
					endif;
				elseif( is_tax() ) : 
					$homeland_term = $wp_query->queried_object;
					$homeland_category_id = $homeland_term->term_id;
					$homeland_category_data = get_option("category_$homeland_category_id"); 
					
					if(!empty($homeland_category_data['homeland_subtitle'])) : ?>
						<h4 class="subtitle"><label><?php echo @$homeland_category_data['homeland_subtitle']; ?></label></h4><?php 
					endif;					
				endif; 
		elseif (is_search()) : ?>
			<h2 class="ptitle">
				<?php
					if(!empty( $homeland_search_header )) : echo $homeland_search_header;
					else : esc_attr( _e( 'Search Results', CODEEX_THEME_NAME ) );
					endif;
				?>
			</h2>
			<h4 class="subtitle">
				<label>
					<?php
						if(!empty( $homeland_search_subtitle )) : echo stripslashes( $homeland_search_subtitle );
						else : esc_attr( _e( 'This is your search subtitle description', CODEEX_THEME_NAME ) );
						endif;
					?>
				</label>
			</h4><?php
		elseif (is_singular('homeland_services')) : ?>
			<h2 class="ptitle">
				<?php 
					if(!empty( $homeland_services_single_header )) : echo $homeland_services_single_header;
					else : esc_attr( _e( 'Our Services', CODEEX_THEME_NAME ) ); 
					endif; 
				?>
			</h2>
			<h4 class="subtitle">
				<label>
					<?php 
						if(!empty( $homeland_services_single_subtitle )) : echo stripslashes( $homeland_services_single_subtitle );
						else : esc_attr( _e( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', CODEEX_THEME_NAME ) );
						endif; 
					?>
				</label>
			</h4><?php
		elseif (is_singular('homeland_properties')) : ?>
			<h2 class="ptitle">
				<?php 
					if(!empty( $homeland_property_single_header )) : echo $homeland_property_single_header;
					else : esc_attr( _e( 'Properties', CODEEX_THEME_NAME ) ); 
					endif; 
				?>
			</h2>
			<h4 class="subtitle">
				<label>
					<?php 
						if(!empty( $homeland_property_single_subtitle )) : echo stripslashes( $homeland_property_single_subtitle );
						else : esc_attr( _e( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', CODEEX_THEME_NAME ) );
						endif; 
					?>
				</label>
			</h4><?php
		elseif (is_single() || is_home()) : ?>
			<h2 class="ptitle">
				<?php 
					if(!empty( $homeland_blog_single_header )) : echo $homeland_blog_single_header;
					else : esc_attr( _e( 'Our Blog', CODEEX_THEME_NAME ) ); 
					endif; 
				?>
			</h2>
			<h4 class="subtitle">
				<label>
					<?php 
						if(!empty( $homeland_blog_single_subtitle )) : echo stripslashes( $homeland_blog_single_subtitle );
						else : esc_attr( _e( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', CODEEX_THEME_NAME ) );
						endif; 
					?>
				</label>
			</h4><?php		
		elseif (is_404()) :	?>
			<h2 class="ptitle">
				<?php 
					if(!empty( $homeland_not_found_header )) : echo $homeland_not_found_header;
					else : esc_attr( _e( '404 Page', CODEEX_THEME_NAME ) ); 
					endif; 
				?>
			</h2>
			<h4 class="subtitle">
				<label>
					<?php 
						if(!empty( $homeland_not_found_subtitle )) : echo stripslashes( $homeland_not_found_subtitle );
						else : esc_attr( _e( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit', CODEEX_THEME_NAME ) );
						endif; 
					?>
				</label>
			</h4><?php
		else :
			$homeland_ptitle = esc_attr( get_post_meta( $post->ID, "homeland_ptitle", true ) );
			$homeland_subtitle = esc_attr( get_post_meta( $post->ID, "homeland_subtitle", true ) );

			if(!empty($homeland_ptitle)) : ?><h2 class="ptitle"><?php echo $homeland_ptitle; ?></h2><?php 
			else : the_title('<h2 class="ptitle">', '</h2>'); endif; 

			if(!empty($homeland_subtitle)) : ?>
				<h4 class="subtitle"><label><?php echo stripslashes($homeland_subtitle); ?></label></h4><?php 
			endif;
		endif;		
	}

	function homeland_get_page_title_subtitle_desc() {
		global $homeland_theme_pages;

		foreach($homeland_theme_pages as $homeland_page) :
			$homeland_page_title = esc_attr( get_post_meta( $homeland_page->ID, "homeland_ptitle", true ) );
			$homepage_subtitle = esc_attr( get_post_meta( $homeland_page->ID, "homeland_subtitle", true ) );

			if($homeland_page_title != "") : $homeland_ptitle = $homeland_page_title;
			else : $homeland_ptitle = esc_attr( $homeland_page->post_title ); endif;
		endforeach; ?>

		<h2 class="ptitle"><?php echo $homeland_ptitle; ?></h2><?php 
		if(!empty($homepage_subtitle)) : ?>
			<h4 class="subtitle"><label><?php echo stripslashes($homeland_subtitle); ?></label></h4><?php 
		endif;
	}


	/**********************************************
	GET PROPERTY TYPE
	***********************************************/

	function homeland_get_property_category() {
		global $homeland_properties_page_url, $homeland_properties_page_2cols_url, $homeland_properties_page_3cols_url, $homeland_properties_page_4cols_url;
		?>
			<div class="cat-toogles">
				<ul class="cat-list clear">
					<li class="<?php if(is_page_template('template-properties.php') || is_page_template('template-properties-2cols.php') || is_page_template('template-properties-3cols.php') || is_page_template('template-properties-4cols.php')) : echo 'current-cat'; endif; ?>"><a href="<?php echo $homeland_properties_page_url; ?>">
						<?php esc_attr( _e( 'All', CODEEX_THEME_NAME ) ); ?></a>
					</li>
					<?php
						$args = array( 'taxonomy' => 'homeland_property_type', 'style' => 'list', 'title_li' => '', 'hierarchical' => false, 'order' => 'ASC', 'orderby' => 'title' );
						wp_list_categories ( $args );
					?>	
				</ul>
			</div>
		<?php
	}	


	/**********************************************
	GET PROPERTY TERMS
	***********************************************/

	function homeland_property_terms() {
		global $post, $homeland_property_status;

		$homeland_terms = get_the_terms( @$post->ID, 'homeland_property_status' ); 
		if ( $homeland_terms && ! is_wp_error( $homeland_terms ) ) : 
			$homeland_property_status = array();
			foreach ( $homeland_terms as $homeland_term ) {
				$homeland_property_status[] = $homeland_term->name;
			}							
			$homeland_property_status = join( ", ", $homeland_property_status );																
		endif;
	}


	/**********************************************
	GET PAGE TEMPLATE LINK
	***********************************************/

	function homeland_template_page_link() {
		global $homeland_blog_page_url, $homeland_contact_page_url, $homeland_properties_page_url, $homeland_properties_page_2cols_url, $homeland_properties_page_3cols_url, 
		$homeland_properties_page_4cols_url, $homeland_about_page_url, $homeland_agent_page_url, $homeland_services_page_url, $homeland_advance_search_page_url;

		$homeland_properties_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-properties.php'));
		foreach($homeland_properties_pages as $page){
			$homeland_properties_page_id = $page->ID;
			$homeland_properties_page_url = get_permalink($homeland_properties_page_id);
		}

		$homeland_properties_pages_4cols = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-properties-4cols.php'));
		foreach($homeland_properties_pages_4cols as $page){
			$homeland_properties_page_4cols_id = $page->ID;
			$homeland_properties_page_4cols_url = get_permalink($homeland_properties_page_4cols_id);
		}

		$homeland_properties_pages_3cols = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-properties-3cols.php'));
		foreach($homeland_properties_pages_3cols as $page){
			$homeland_properties_page_3cols_id = $page->ID;
			$homeland_properties_page_3cols_url = get_permalink($homeland_properties_page_3cols_id);
		}

		$homeland_properties_pages_2cols = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-properties-2cols.php'));
		foreach($homeland_properties_pages_2cols as $page){
			$homeland_properties_page_2cols_id = $page->ID;
			$homeland_properties_page_2cols_url = get_permalink($homeland_properties_page_2cols_id);
		}

		$homeland_blog_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-blog.php'));
		foreach($homeland_blog_pages as $page){
			$homeland_blog_page_id = $page->ID;
			$homeland_blog_page_url = get_permalink($homeland_blog_page_id);
		}

		$homeland_contact_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-contact.php'));
		foreach($homeland_contact_pages as $page){
			$homeland_contact_page_id = $page->ID;
			$homeland_contact_page_url = get_permalink($homeland_contact_page_id);
		}

		$homeland_about_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-about.php'));
		foreach($homeland_about_pages as $page){
			$homeland_about_page_id = $page->ID;
			$homeland_about_page_url = get_permalink($homeland_about_page_id);
		}

		$homeland_agent_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-agents.php'));
		foreach($homeland_agent_pages as $page){
			$homeland_agent_page_id = $page->ID;
			$homeland_agent_page_url = get_permalink($homeland_agent_page_id);
		}

		$homeland_services_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-services.php'));
		foreach($homeland_services_pages as $page){
			$homeland_services_page_id = $page->ID;
			$homeland_services_page_url = get_permalink($homeland_services_page_id);
		}

		$homeland_advance_search_pages = get_pages(array('meta_key' => '_wp_page_template', 'meta_value' => 'template-property-search.php'));
		foreach($homeland_advance_search_pages as $page){
			$homeland_advance_search_page_id = $page->ID;
			$homeland_advance_search_page_url = get_permalink($homeland_advance_search_page_id);
		}
	}


	/**********************************************
	CUSTOM EXCERPT LENGTH
	***********************************************/

	function homeland_custom_excerpt_length( $length ) {
		return 30;
	}
	add_filter( 'excerpt_length', 'homeland_custom_excerpt_length', 999 );

	function homeland_custom_excerpt_more( $more ) {
		return ' ...';
	}
	add_filter( 'excerpt_more', 'homeland_custom_excerpt_more' );


	/**********************************************
	REMOVE DEFAULT COMMENT FIELDS
	***********************************************/

	function homeland_remove_comment_fields($arg) {
	    $arg['url'] = '';
	    return $arg;
	}
	add_filter('comment_form_default_fields', 'homeland_remove_comment_fields');

	
	/**********************************************
	CUSTOM COMMENT STYLE
	***********************************************/

	function homeland_theme_comment($comment, $args, $depth) {
		$GLOBALS['comment'] = $comment; ?>
			
			<li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
				<div class="parent clear" id="comment-<?php comment_ID(); ?>">					
					<?php echo get_avatar( $comment, 60 ); ?>
					<div class="comment-details">
						<h5><?php comment_author_link(); ?>
							<span><?php echo human_time_diff( get_comment_time('U'), current_time('timestamp') ) . ' ago'; ?> <?php edit_comment_link('edit','&nbsp;',''); ?></span>	
						</h5> 
						<?php 
							comment_text(); 
							comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'])));
							edit_comment_link('edit','&nbsp;',''); 
							if ($comment->comment_approved == '0') : ?><em><?php _e( 'Your comment is awaiting moderation.', CODEEX_THEME_NAME ); ?></em><?php 
							endif; 					
						?>
					</div>
				</div>	
			
			<?php
				$oddcomment = ( empty( $oddcomment ) ) ? 'class="alt" ' : '';
				paginate_comments_links();
	}


	/**********************************************
	CUSTOM PAGINATION
	***********************************************/

	function homeland_pagination() {  
		global $wp_query;
		$big = 999999999;
		if($wp_query->max_num_pages == '1' ) : else : echo "<div class=\"pagination clear\">"; endif;
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
			'format' => '?paged=%#%',
			'prev_text' => __( '&laquo;', CODEEX_THEME_NAME ),
    		'next_text' => __( '&raquo;', CODEEX_THEME_NAME ),
			'current' => max( 1, get_query_var('paged') ),
			'total' => $wp_query->max_num_pages,
			'type' => 'list'
		));
		if($wp_query->max_num_pages == '1' ) : else : echo "</div>"; endif;
	}


	/**********************************************
	CUSTOM NEXT PREVIOUS LINK
	***********************************************/

	function homeland_next_previous() {
		?>
		<div class="pagination">
			<?php
			   global $wp_query, $paged;		    
			   if ($paged > 1) : ?>
			   	<div class="alignleft">
			   		<a href="<?php previous_posts(); ?>">&larr; <?php _e( 'Previous', CODEEX_THEME_NAME ); ?></a>
			   	</div><?php
			   endif;
			    
			   if ($wp_query->max_num_pages == 1) :	    		
		    	elseif ($paged < $wp_query->max_num_pages) : ?>
		    		<div class="alignright">
		    			<a href="<?php next_posts(); ?>"><?php _e( 'Next', CODEEX_THEME_NAME ); ?> &rarr;</a>
		    		</div><?php
		    	endif;
			?>
		</div>
		<?php
	}


	/**********************************************
	FIX PAGINATION FOR TAXONOMIES
	***********************************************/

	$homeland_posts_per_page = get_option( 'posts_per_page' );
	
	function homeland_modify_posts_per_page() { 
		add_filter( 'option_posts_per_page', 'homeland_option_posts_per_page' ); 
	}
	add_action( 'init', 'homeland_modify_posts_per_page', 0);

	function homeland_option_posts_per_page( $value ) {
	    global $homeland_posts_per_page, $wp_query;
	    if ( is_tax( 'homeland_properties_categories') ) : return $wp_query->max_num_pages;
	    else : return $homeland_posts_per_page; endif;
	}


	/**********************************************
	FOR PAGINATION WORKING ON STATIC HOMEPAGE
	***********************************************/

	function homeland_get_home_pagination() {
		global $paged, $wp_query, $wp;
		$args = wp_parse_args($wp->matched_query);
		if ( !empty ( $args['paged'] ) && 0 == $paged ) :
			$wp_query->set('paged', $args['paged']);
		  	$paged = $args['paged'];
		endif;
	}

	/**********************************************
	FOR PAGINATION WORKING ON AGENT/AUTHOR
	***********************************************/

	function homeland_custom_agent_pagination( &$query ) {
    	if ($query->is_author) $query->set( 'post_type', array( 'homeland_properties' ) );
	}
	add_action( 'pre_get_posts', 'homeland_custom_agent_pagination' );


	/**********************************************
	AGENT CONTRIBUTOR UPLOAD FILES
	***********************************************/

	function homeland_allow_contributor_uploads() {
 		$contributor = get_role('contributor');
 		$contributor->add_cap('upload_files');
	}
	if ( current_user_can('contributor') && !current_user_can('upload_files') )
 	add_action('admin_init', 'homeland_allow_contributor_uploads');


	/**********************************************
	SEARCH FILTER : BLOG POST ONLY
	***********************************************/

	function homeland_searchfilter($homeland_query) {
	    if ( !$homeland_query->is_admin && $homeland_query->is_search ) : 
	    	$homeland_query->set( 'post_type', array( 'post', 'homeland_properties' ) );
	    endif;

	    return $homeland_query;
	}	 
	add_filter('pre_get_posts','homeland_searchfilter');


	/**********************************************
	ADVANCE PROPERTY SEARCH
	***********************************************/

	function homeland_advance_property_search($homeland_search_args) {
		$homeland_tax_query = array();
		$homeland_meta_query = array();

		if( (!empty($_GET['location'])) ) : $homeland_tax_query[] = array( 'taxonomy' => 'homeland_property_location', 'field' => 'slug', 'terms' => $_GET['location'] ); endif;
		if( (!empty($_GET['type'])) ) : $homeland_tax_query[] = array( 'taxonomy' => 'homeland_property_type', 'field' => 'slug', 'terms' => $_GET['type'] ); endif;
		if( (!empty($_GET['status'])) ) : $homeland_tax_query[] = array( 'taxonomy' => 'homeland_property_status', 'field' => 'slug', 'terms' => $_GET['status'] ); endif;
		if( (!empty($_GET['bed'])) ) : $homeland_meta_query[] = array( 'key' => 'homeland_bedroom', 'value' => $_GET['bed'], 'type'=> 'NUMERIC', 'compare' => '=' ); endif;
		if( (!empty($_GET['bath'])) ) : $homeland_meta_query[] = array( 'key' => 'homeland_bathroom', 'value' => $_GET['bath'], 'type'=> 'NUMERIC', 'compare' => '=' ); endif;

		if( isset($_GET['min-price']) && isset($_GET['max-price']) ) :
            
	      /*BOTH MIN-MAX PRICE*/
	     	if($_GET['min-price'] != "" && $_GET['max-price'] != "") :
          	$homeland_min_price = intval($_GET['min-price']);
	         $homeland_max_price = intval($_GET['max-price']);
	         
				if( $homeland_min_price >= 0 && $homeland_max_price > $homeland_min_price ) :
				  $homeland_meta_query[] = array( 'key' => 'homeland_price', 'value' => array( $homeland_min_price, $homeland_max_price ), 'type' => 'NUMERIC', 'compare' => 'BETWEEN' );
				endif;
	      
	      /*MINIMUM PRICE*/
	      elseif($_GET['min-price'] != "") :
	      	$homeland_min_price = $_GET['min-price'];   
	      	if( $homeland_min_price > 0 ) : $homeland_meta_query[] = array( 'key' => 'homeland_price', 'value' => $homeland_min_price, 'type' => 'NUMERIC', 'compare' => '>=' ); endif;

	      /*MAXIMUM PRICE*/
	      elseif($_GET['max-price'] != "") :
	          $homeland_max_price = intval($_GET['max-price']);
	          if( $homeland_max_price > 0 ) : $homeland_meta_query[] = array( 'key' => 'homeland_price', 'value' => $homeland_max_price, 'type' => 'NUMERIC', 'compare' => '<=' ); endif;
	 		endif;

	  	endif;        

		$homeland_tax_count = count( $homeland_tax_query );
		if( $homeland_tax_count > 1 ) : $homeland_tax_query['relation'] = 'AND'; endif;

		$homeland_meta_count = count( $homeland_meta_query );
		if( $homeland_meta_count > 1 ) : $homeland_meta_query['relation'] = 'AND'; endif;
		if( $homeland_tax_count > 0 ) : $homeland_search_args['tax_query'] = $homeland_tax_query; endif;
		if( $homeland_meta_count > 0 ) : $homeland_search_args['meta_query'] = $homeland_meta_query; endif;

		return $homeland_search_args;
   }

   add_filter('homeland_advance_search_parameters', 'homeland_advance_property_search');


   /**********************************************
	PROPERTY SORT and ORDER
	***********************************************/ 

	function homeland_property_sort_order() {
		$homeland_path = $_SERVER['REQUEST_URI'];
		?>
			<div class="clear">
				<div class="filter-sort-order">
					<form action="<?php echo $homeland_path; ?>" method="get" class="form-sorting-order">

						<?php
							if(is_page_template('template-property-search.php')) : ?>
								<input type="hidden" name="location" value="<?php echo $_GET['location']; ?>">
		                  <input type="hidden" name="status" value="<?php echo $_GET['status']; ?>">
		                  <input type="hidden" name="type" value="<?php echo $_GET['type']; ?>">
		                  <input type="hidden" name="bed" value="<?php echo $_GET['bed']; ?>">
		                  <input type="hidden" name="bath" value="<?php echo $_GET['bath']; ?>">
		                  <input type="hidden" name="min-price" value="<?php echo $_GET['min-price']; ?>">
		                  <input type="hidden" name="max-price" value="<?php echo $_GET['max-price']; ?>"><?php
							endif;
						?>

						<label for="input_order"><?php _e( 'Order', CODEEX_THEME_NAME ); ?></label>
					 	<select name="filter-order" id="input_order">
				         <?php
								$homeland_filter_order = @$_GET['filter-order'];
								$homeland_array = array('DESC', 'ASC');

								foreach($homeland_array as $homeland_order_option) :
				               if($homeland_filter_order == $homeland_order_option) :
				               	echo '<option value="'. $homeland_order_option .'" selected="selected">'. $homeland_order_option .'</option>';
				               else :
				                  echo '<option value="'. $homeland_order_option .'">'. $homeland_order_option .'</option>';
				               endif;
				            endforeach;
							?>		
				     	</select>
				     	<label for="input_sort"><?php _e( 'Sort By', CODEEX_THEME_NAME ); ?></label>
					 	<select name="filter-sort" id="input_sort">
							<?php
								$homeland_filter_sort = @$_GET['filter-sort'];
								$homeland_array = array('date' => 'Date', 'title' => 'Name', 'homeland_price' => 'Price');

								foreach($homeland_array as $homeland_sort_option_value=>$homeland_sort_option) :
				               if($homeland_filter_sort == $homeland_sort_option_value) :
				               	echo '<option value="'. $homeland_sort_option_value .'" selected="selected">'. $homeland_sort_option .'</option>';
				               else :
				                  echo '<option value="'. $homeland_sort_option_value .'">'. $homeland_sort_option .'</option>';
				               endif;
				            endforeach;
							?>		
						</select>                                                                                        
				   </form>	
				</div>
			</div>
		<?php
	}


	/**********************************************
	REMOVE & ADD NEW FIELD IN USER PROFILE
	***********************************************/

	function homeland_remove_aim( $homeland_contactmethods ) {
		unset($homeland_contactmethods['aim']);
		unset($homeland_contactmethods['jabber']);
		unset($homeland_contactmethods['yim']);
		return $homeland_contactmethods;
	}
	add_filter('user_contactmethods','homeland_remove_aim',10,1);

	function homeland_add_new_contact_info( $homeland_contactmethods ) {
	    $homeland_contactmethods['homeland_designation'] = 'Designation';
	    $homeland_contactmethods['homeland_twitter'] = 'Twitter';
	    $homeland_contactmethods['homeland_facebook'] = 'Facebook';
	    $homeland_contactmethods['homeland_gplus'] = 'Google+';
	    $homeland_contactmethods['homeland_linkedin'] = 'LinkedIn';
	    $homeland_contactmethods['homeland_telno'] = 'TelNo.';
	    $homeland_contactmethods['homeland_mobile'] = 'Mobile';
	    $homeland_contactmethods['homeland_fax'] = 'Fax';
	    return $homeland_contactmethods;
	}
	add_filter('user_contactmethods','homeland_add_new_contact_info',10,1);


	/**********************************************
	ADD POST THUMBNAIL SIZE IN MEDIA UPLOAD
	***********************************************/

	function homeland_get_additional_image_sizes() {
		$sizes = array();
		global $_wp_additional_image_sizes;
		if ( isset($_wp_additional_image_sizes) && count($_wp_additional_image_sizes) ) {
			$sizes = apply_filters( 'intermediate_image_sizes', $_wp_additional_image_sizes );
			$sizes = apply_filters( 'homeland_get_additional_image_sizes', $_wp_additional_image_sizes );
		}
		return $sizes;
	}

	function additional_image_size_input_fields( $fields, $post ) {
		if ( !isset($fields['image-size']['html']) || substr($post->post_mime_type, 0, 5) != 'image' )
			return $fields;

		$sizes = homeland_get_additional_image_sizes();
		if ( !count($sizes) )
			return $fields;

		$items = array();
		foreach ( array_keys($sizes) as $size ) {
			$downsize = image_downsize( $post->ID, $size );
			$enabled = $downsize[3];
			$css_id = "image-size-{$size}-{$post->ID}";
			$label = apply_filters( 'image_size_name', $size );

			$html  = "<div class='image-size-item'>\n";
			$html .= "<input type='radio' " . disabled( $enabled, false, false ) . "name='attachments[{$post->ID}][image-size]' id='{$css_id}' value='{$size}' />\n";
			$html .= "<label for='{$css_id}'>{$label}</label>\n";
			if ( $enabled )
				$html .= "<label for='{$css_id}' class='help'>" . sprintf( "(%d x %d)", $downsize[1], $downsize[2] ). "</label>\n";
			$html .= "</div>";

			$items[] = $html;
		}

		$items = join( "\n", $items );
		$fields['image-size']['html'] = "{$fields['image-size']['html']}\n{$items}";

		return $fields;
	}

	add_filter( 'attachment_fields_to_edit', 'additional_image_size_input_fields', 11, 2 );


	/**********************************************
	ADD CATEGORY FIELD
	***********************************************/

	function homeland_create_category_fields( $homeland_tag ) {    
    	$homeland_extra_id = @$homeland_tag->term_id;
    	$homeland_cat_meta = get_option( "category_$homeland_extra_id");
		?>
			<div class="form-field">
				<label for="homeland_cat_meta[homeland_subtitle]"><?php _e( 'Subtitle', CODEEX_THEME_NAME ); ?></label>
				<input type="text" name="homeland_cat_meta[homeland_subtitle]" id="homeland_cat_meta[homeland_subtitle]" value="<?php echo $homeland_cat_meta['homeland_subtitle'] ? $homeland_cat_meta['homeland_subtitle'] : ''; ?>">
			    <p><?php esc_attr( _e( 'This is use in the subtitle of the category', CODEEX_THEME_NAME ) ); ?></p>			        
			</div>
		<?php
	}

	function homeland_edit_category_fields( $homeland_tag ) {    
    	$homeland_extra_id = $homeland_tag->term_id;
    	$homeland_cat_meta = get_option( "category_$homeland_extra_id");
		?>
			<tr class="form-field">
				<th valign="top" scope="row"><label for="homeland_cat_meta[homeland_subtitle]"><?php _e( 'Subtitle', CODEEX_THEME_NAME ); ?></label></th>
				<td>
					<input type="text" name="homeland_cat_meta[homeland_subtitle]" id="homeland_cat_meta[homeland_subtitle]" value="<?php echo $homeland_cat_meta['homeland_subtitle'] ? $homeland_cat_meta['homeland_subtitle'] : ''; ?>"><br>
					<span class="description"><?php esc_attr( _e( 'This is use in the subtitle of the category', CODEEX_THEME_NAME ) ); ?></span>
				</td>		        
			</tr>
		<?php
	}

	add_action ( 'category_edit_form_fields', 'homeland_edit_category_fields');
	add_action ( 'category_add_form_fields', 'homeland_create_category_fields');
	add_action ( 'homeland_property_type_edit_form_fields', 'homeland_edit_category_fields');
	add_action ( 'homeland_property_type_add_form_fields', 'homeland_create_category_fields');
	add_action ( 'homeland_property_status_edit_form_fields', 'homeland_edit_category_fields');
	add_action ( 'homeland_property_status_add_form_fields', 'homeland_create_category_fields');

	function homeland_save_extra_category_fields( $term_id ) {
		if ( isset( $_POST['homeland_cat_meta'] ) ) {
			$homeland_extra_id = $term_id;
			$homeland_cat_meta = get_option( "category_$homeland_extra_id");
			$homeland_cat_keys = array_keys($_POST['homeland_cat_meta']);
			   foreach ($homeland_cat_keys as $homeland_key){
			   if (isset($_POST['homeland_cat_meta'][$homeland_key])){
			      $homeland_cat_meta[$homeland_key] = $_POST['homeland_cat_meta'][$homeland_key];
			   }
			}
			update_option( "category_$homeland_extra_id", $homeland_cat_meta );        
		}
	}

	add_action ( 'edited_category', 'homeland_save_extra_category_fields');
	add_action ( 'create_category', 'homeland_save_extra_category_fields');
	add_action ( 'edited_homeland_property_type', 'homeland_save_extra_category_fields');
	add_action ( 'create_homeland_property_type', 'homeland_save_extra_category_fields');
	add_action ( 'edited_homeland_property_status', 'homeland_save_extra_category_fields');
	add_action ( 'create_homeland_property_status', 'homeland_save_extra_category_fields');


	/**********************************************
	CONVERT HEX TO RGBA
	***********************************************/

	function homeland_hex2rgba($homeland_color, $homeland_opacity = false) {
		$homeland_default = 'rgb(0,0,0)';
		if(empty($homeland_color))
	        return $homeland_default; 
	        if ($homeland_color[0] == '#' ) {
	        	$homeland_color = substr( $homeland_color, 1 );
	        }

	        if (strlen($homeland_color) == 6) :
	            $homeland_hex = array( $homeland_color[0] . $homeland_color[1], $homeland_color[2] . $homeland_color[3], $homeland_color[4] . $homeland_color[5] );
	        elseif ( strlen( $homeland_color ) == 3 ) :
	            $homeland_hex = array( $homeland_color[0] . $homeland_color[0], $homeland_color[1] . $homeland_color[1], $homeland_color[2] . $homeland_color[2] );
	        else :
	            return $homeland_default;
	        endif;

	        $homeland_rgb =  array_map('hexdec', $homeland_hex);

	        if($homeland_opacity) :
	        	if(abs($homeland_opacity) > 1)
	        		$homeland_opacity = 1.0;
	        		$homeland_output = 'rgba('.implode(",",$homeland_rgb).','.$homeland_opacity.')';
	        else :
	        	$homeland_output = 'rgb('.implode(",",$homeland_rgb).')';
	        endif;

	        return $homeland_output;
	}	


	/**********************************************
	CUSTOM THEME STYLESHEETS
	***********************************************/

	function homeland_theme_custom_styles() {
		?><style type="text/css"><?php	

		/*PATTERNS*/

		if(get_option('homeland_bg_type') == "Pattern") :
			if(get_option('homeland_pattern')=="Gray Lines") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/gray_lines.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Noise Lines") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/noise_lines.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Tiny Grid") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/tiny_grid.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Bullseye") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/strange_bullseyes.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Gray Paper") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/gray_paper.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Norwegian Rose") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/norwegian_rose.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Subtle Net") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/subtlenet.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Polyester Lite") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/polyester_lite.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Absurdity") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/absurdidad.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="White Bed Sheet") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/white_bed_sheet.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Subtle Stripes") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/subtle_stripes.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Light Mesh") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/lghtmesh.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Rough Diagonal") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/rough_diagonal.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Arabesque") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/arab_tile.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Stack Circles") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/stacked_circles.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Hexellence") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/hexellence.png') repeat top fixed fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="White Texture") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/white_texture.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Concrete Wall") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/concrete_wall.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Brush Aluminum") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/brushed_alu.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Groovepaper") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/groovepaper.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Diagonal Noise") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/diagonal_noise.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Rocky Wall") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/rockywall.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Whitey") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/whitey.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Bright flexs") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/bright_flexs.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Freckles") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/freckles.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Wallpaper") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/wallpaper.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Project Paper") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/project_papper.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Cubes") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/cubes.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Washi") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/washi.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Dot Noise") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/dotnoise.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="xv") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/xv.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Little Plaid") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/plaid.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Old Wall") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/old_wall.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Connect") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/connect.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Ravenna") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/ravenna.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Smooth Wall") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/smooth_wall.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Tapestry") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/tapestry.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Psychedelic") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/psychedelic.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Scribble Light") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/scribble_light.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="GPlay") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/gplay.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Lil Fiber") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/lil_fiber.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="First Aid") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/first_aid.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Frenchstucco") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/frenchstucco.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Light Wool") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/light_wool.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Gradient flexs") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/gradient_flexs.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Escheresque") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/escheresque.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Climpek") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/climpek.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Lyonnette") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/lyonnette.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Gray Floral") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/greyfloral.png') repeat top fixed !important; }<?php
			elseif(get_option('homeland_pattern')=="Reticular Tissue") :
				?>body { background:url('<?php echo get_template_directory_uri(); ?>/img/patterns/reticular_tissue.png') repeat top fixed !important; }<?php
			endif;
		endif;
		

		/*CUSTOM COLORS*/

		$homeland_theme_color_global = get_option('homeland_global_color');
		$homeland_rgb_theme_color = homeland_hex2rgba($homeland_theme_color_global);
		$homeland_rgba_theme_color = homeland_hex2rgba($homeland_theme_color_global, 0.8);

		if(get_option('homeland_global_color')!="" ) : ?>
			.search-title span, .selectBox-dropdown .selectBox-arrow, 
			.home-flexslider .flex-direction-nav li .flex-next:hover, 
			.home-flexslider .flex-direction-nav li .flex-prev:hover, 
			.properties-flexslider .flex-direction-nav li .flex-next:hover, 
			.properties-flexslider .flex-direction-nav li .flex-prev:hover,
			.blog-flexslider .flex-direction-nav li .flex-next:hover, 
			.blog-flexslider .flex-direction-nav li .flex-prev:hover, .services-desc a.more, .cat-price,
			.grid li:hover .property-info, .pimage figcaption i, .feat-thumb figcaption i, .feat-medium figcaption i,
			.nsu-submit, a#toTop, .pactions a:link, .pactions a:visited, 
			.theme-menu ul li.current-menu-item a, .theme-menu ul li.current-menu-ancestor a, 
			.theme-menu ul li.current-menu-parent a, .theme-menu ul li a:hover, 
			.sf-menu li.sfHover a, .sf-menu li.sfHover a:after, .cat-toogles ul li.current-cat a, 
			.cat-toogles ul li a:hover, .page-numbers li a:hover, .alignleft a:hover, .alignright a:hover, 
			.post-link-blog .prev a:hover, .post-link-blog .next a:hover, span.current, a.continue, .wpcf7-submit, #submit,
			.page-template-template-homepage2-php .hi-icon-effect-1 .hi-icon,
			.advance-search-widget ul li input[type="submit"], 
			.dsidx-widget.dsidx-search-widget 
			.dsidx-search-button input[type="submit"], #dsidx-price,
			#dsidx.dsidx-details .dsidx-contact-form table input[type="button"],
			.property-four-cols .view-details a, .agent-form ul li input[type="submit"] { 
				background:<?php echo get_option('homeland_global_color'); ?> 
			} 
			.sfHover ul li.sfHover a.sf-with-ul, a.back-home:link, a.back-home:visited { background:<?php echo get_option('homeland_global_color') ?> !important; }
			.hi-icon, .no-touch .hi-icon-effect-1a .hi-icon:hover, .property-desc h4 a:hover, a.view-property:hover,
			.agent-block label span, .homeland_widget-agents label span, .agent-block h4 a:hover, .feat-desc span.price,
			.sf-menu li.sfHover ul li a:hover, .widget ul li a:hover, .widget ul li:hover:before, .copyright a, 
			.agent-block h4 a:hover, .agent-desc h4 a:hover, .agent-social ul li a:hover, .sidebar .pp-desc a:hover, 
			.services-page-desc h5 a:hover, .agent-about-list .agent-image h4 a:hover, 
			.blog-list-desc h4 a:hover, .blog-action ul li a:hover,
			.comment-details h5 a:hover, .property-desc-slide span, .agent-info label,
			.property-three-cols .property-desc span.price, .property-four-cols .view-details a, 
			.agent-desc label.listed span, .contact-info label, .feat-desc h5 a:hover, .bdesc h5 a:hover,
			#dsidx-listings .dsidx-price, .featured-listing .price, 
			.dsidx-prop-title, a.dsidx-actions-button:hover, 
			#dsidx a:hover, .featured-listing h4 a:hover, 
			div.dsidx-results-widget .dsidx-controls a:hover, 
			.marker-window h5, .sitemap a:hover { color:<?php echo get_option('homeland_global_color') ?> !important; } 
			.page-template-template-homepage2-php .hi-icon, .property-four-cols .view-details a { color:#FFF !important; }
			.hi-icon { border-color:<?php echo get_option('homeland_global_color'); ?> } 
			.advance-search-block.advance-search-block-page .inside, 
			.property-page-price { background:<?php echo $homeland_rgba_theme_color; ?> } <?php
		endif;

		if(get_option('homeland_menu_text_color')!="" ) : ?>
			.theme-menu ul li a { color:<?php echo get_option('homeland_menu_text_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_menu_bg_color')!="" ) : ?>
			.theme-menu ul li.current-menu-item a, .theme-menu ul li.current-menu-ancestor a, 
			.theme-menu ul li.current-menu-parent a, .theme-menu ul li a:hover, .sf-menu li.sfHover a,
			.sfHover ul li.sfHover a.sf-with-ul { background-color:<?php echo get_option('homeland_menu_bg_color') ?> !important; } 
			.sf-menu li:hover ul a, .sf-menu li.sfHover ul a { background:#F2F2F2 !important; } <?php
		endif;

		if(get_option('homeland_header_text_color')!="" ) : ?>
			.ptitle, .widget h5, .property-list-box h2, .agent-block h3, .featured-block h3, .blog-block h3,
			.services-desc h5 { color:<?php echo get_option('homeland_header_text_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_sidebar_text_color')!="" ) : ?>.sidebar .widget h5 { color:<?php echo get_option('homeland_sidebar_text_color') ?> !important; }<?php endif;

		if(get_option('homeland_button_bg_color')!="" ) : ?>
			.contact-form input[type="submit"], #respond input[type="submit"],
			.services-desc a.more, .pactions a i, .feat-thumb figcaption a i, .feat-medium figcaption a i, .pimage figcaption a i, 
			a#toTop, .nsu-submit, .advance-search-block input[type="submit"], 
			a.back-home:link, a.back-home:visited, a.continue, 
			.advance-search-widget ul li input[type="submit"], 
			.dsidx-widget.dsidx-search-widget .dsidx-search-button input[type="submit"],
			#dsidx.dsidx-details .dsidx-contact-form table input[type="button"],
			.property-four-cols .view-details a, .agent-form ul li input[type="submit"] { background-color:<?php echo get_option('homeland_button_bg_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_button_bg_hover_color')!="" ) : ?>
			.contact-form input[type="submit"]:hover, #respond input[type="submit"]:hover,
			.services-desc a.more:hover, .pactions a i:hover, .feat-thumb figcaption a i:hover, .feat-medium figcaption a i:hover, .pimage figcaption a i:hover,
			a#toTop:hover, .nsu-submit:hover, 
			.advance-search-block input[type="submit"]:hover, a.back-home:hover, 
			a.continue:hover, 
			.advance-search-widget ul li input[type="submit"]:hover, 
			.dsidx-widget.dsidx-search-widget .dsidx-search-button input[type="submit"]:hover,
			#dsidx.dsidx-details .dsidx-contact-form table input[type="button"]:hover,
			.property-four-cols .view-details a:hover, .agent-form ul li input[type="submit"]:hover { background-color:<?php echo get_option('homeland_button_bg_hover_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_button_text_color')!="" ) :	?>
			.contact-form input[type="submit"], #respond input[type="submit"],
			.services-desc a.more, .pactions a i, .feat-thumb figcaption a i, .feat-medium figcaption a i, .pimage figcaption a i, 
			a#toTop, a.continue { color:<?php echo get_option('homeland_button_text_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_footer_bg_color')!="" ) :	?>
			footer { background-color:<?php echo get_option('homeland_footer_bg_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_footer_text_color')!="" ) :	?>
			footer, .widget-column { color:<?php echo get_option('homeland_footer_text_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_slide_top_bg_color')!="" ) :	?>
			.sliding-bar, 
			a.slide-toggle { color:#FFF; background-color:<?php echo get_option('homeland_slide_top_bg_color') ?> !important; } <?php
		endif;

		if(get_option('homeland_custom_css')!="") : echo get_option('homeland_custom_css'); endif;
		?></style><?php
	}
	add_action( 'wp_head', 'homeland_theme_custom_styles' );



	/**********************************************
	CUSTOM RESIZABLE BACKGROUND
	***********************************************/

	function homeland_theme_custom_background() {
		global $post;
		$homeland_bgimage = get_post_meta(@$post->ID, "homeland_bgimage", true);
		$homeland_archive_bgimage = get_option('homeland_archive_bgimage');
		$homeland_search_bgimage = get_option('homeland_search_bgimage');
		$homeland_notfound_bgimage = get_option('homeland_notfound_bgimage');
		$homeland_agent_bgimage = get_option('homeland_agent_bgimage');
		$homeland_bg_type = get_option('homeland_bg_type');

		if(is_archive()) :
			if(is_author()) :
				if($homeland_bg_type == "Image") :
					if(!empty($homeland_agent_bgimage)) : ?>
						<script type="text/javascript"> 
							jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_agent_bgimage; ?>"); }); 
						</script><?php					
					else : homeland_default_img_bg(); endif;
				elseif($homeland_bg_type == "Color") : homeland_bg_color(); endif;		
			else :
				if($homeland_bg_type == "Image") :
					if(!empty($homeland_archive_bgimage)) : ?>
						<script type="text/javascript"> 
							jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_archive_bgimage; ?>"); }); 
						</script><?php	
					else : homeland_default_img_bg(); endif;
				elseif($homeland_bg_type == "Color") : homeland_bg_color(); endif;		
			endif;
		elseif(is_search()) :
			if($homeland_bg_type == "Image") :
				if(!empty($homeland_search_bgimage)) : ?>
					<script type="text/javascript"> 
						jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_search_bgimage; ?>"); }); 
					</script><?php					
				else : homeland_default_img_bg(); endif;
			elseif($homeland_bg_type == "Color") : homeland_bg_color(); endif;	
		elseif(is_404()) :
			if($homeland_bg_type == "Image") :
				if(!empty($homeland_notfound_bgimage)) : ?>
					<script type="text/javascript"> 
						jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_notfound_bgimage; ?>"); }); 
					</script><?php						
				else : homeland_default_img_bg(); endif;
			elseif($homeland_bg_type == "Color") : homeland_bg_color(); endif;	
		elseif(is_page_template('template-coming-soon.php')) :
		elseif(is_page() || is_single()) :
			if($homeland_bg_type == "Image") :
				if(!empty($homeland_bgimage)) : ?>
					<script type="text/javascript">
						jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_bgimage; ?>"); });
					</script><?php					
				else : homeland_default_img_bg(); endif;	
			elseif($homeland_bg_type == "Color") : homeland_bg_color(); endif;
		else :
			homeland_default_img_bg();
		endif;
	}	
	add_action( 'wp_footer', 'homeland_theme_custom_background' );


	/*BACKGROUND DEFAULT IMAGE*/

	function homeland_default_img_bg() {
		$homeland_default_bgimage = get_option('homeland_default_bgimage');

		if(!empty($homeland_default_bgimage)) : ?>
			<script type="text/javascript"> 
				jQuery(window).load(function() { jQuery.backstretch("<?php echo $homeland_default_bgimage; ?>"); }); 
			</script><?php	
		else : ?>
			<script type="text/javascript"> 
				jQuery(window).load(function() { jQuery.backstretch("<?php echo home_url(); ?>/wp-content/uploads/2013/12/View-over-the-lake_www.LuxuryWallpapers.net_.jpg"); }); 
			</script><?php
		endif;
	}	


	/*BACKGROUND COLOR*/

	function homeland_bg_color() {
		?><style type="text/css"> body { background-color: <?php echo get_option('homeland_bg_color'); ?>; }</style><?php	
	}
	add_action( 'wp_head', 'homeland_bg_color' );


	/*HEADER BACKGROUND IMAGE*/

	function homeland_header_image() {
		global $post;

		$homeland_page_hd_image = esc_attr( get_post_meta( @$post->ID, 'homeland_hdimage', true ) );
		$homeland_archive_hdimage = get_option('homeland_archive_hdimage');
		$homeland_search_hdimage = get_option('homeland_search_hdimage');
		$homeland_notfound_hdimage = get_option('homeland_notfound_hdimage');
		$homeland_agent_hdimage = get_option('homeland_agent_hdimage');
		$homeland_default_hdimage = get_option('homeland_default_hdimage');

		if(!empty($homeland_default_hdimage)) : $homeland_default_hdbanner = $homeland_default_hdimage; 
		else : $homeland_default_hdbanner = home_url() . "/wp-content/uploads/2013/12/View-over-the-lake_www.LuxuryWallpapers.net_-1920x300.jpg"; endif;
		?>
		<style type="text/css">
			.page-title-block-default { background:url('<?php echo $homeland_default_hdbanner; ?>'); }
			<?php 
				if(is_archive()) : 
					if(is_author()) : ?>
						.page-title-block-agent { background:url('<?php echo $homeland_agent_hdimage; ?>'); } <?php 
					else : ?>
						.page-title-block-archive { background:url('<?php echo $homeland_archive_hdimage; ?>'); } <?php 
					endif; 
				elseif(is_search()) : ?>.page-title-block-search { background:url('<?php echo $homeland_search_hdimage; ?>'); } <?php 
				elseif(is_404()) : ?>.page-title-block-error { background:url('<?php echo $homeland_notfound_hdimage; ?>'); } <?php 
				elseif(is_author()) : ?>.page-title-block-agent { background:url('<?php echo $homeland_agent_hdimage; ?>'); } <?php 
				else : ?>.page-title-block { background:url('<?php echo $homeland_page_hd_image; ?>'); } <?php endif; ?>		
		</style>
		<?php
			if(is_page_template('template-homepage.php') || is_page_template('template-homepage2.php') || is_page_template('template-homepage3.php') || is_page_template('template-homepage4.php') || is_page_template('template-homepage-video.php') || is_page_template('template-homepage-revslider.php') || is_page_template('template-homepage-gmap.php')) :  
			else :
				if(is_archive()) :
					if(is_author()) :
						if(!empty($homeland_agent_hdimage)) : ?>
							<section class="page-title-block-agent header-bg"><?php 
						else : ?><section class="page-title-block-default header-bg"><?php 
						endif;
					else :
						if(!empty($homeland_archive_hdimage)) : ?>
							<section class="page-title-block-archive header-bg"><?php 
						else : ?><section class="page-title-block-default header-bg"><?php 
						endif;
					endif;
				elseif(is_search()) : 
					if(!empty($homeland_search_hdimage)) : ?><section class="page-title-block-search header-bg"><?php else : ?><section class="page-title-block-default header-bg"><?php endif;
				elseif(is_404()) :
					if(!empty($homeland_notfound_hdimage) != "") : ?><section class="page-title-block-error header-bg"><?php else : ?><section class="page-title-block-default header-bg"><?php endif;
				else :
					if(!empty($homeland_page_hd_image)) : ?>
						<section class="page-title-block header-bg"><?php 
					else : ?>
						<section class="page-title-block-default header-bg"><?php 
					endif;
				endif;
				?><div class="inside"><?php homeland_get_page_title(); ?></div></section><?php 
			endif; 
	}


	/**********************************************
	THEME FONT SELECTION
	***********************************************/

	function homeland_custom_font_family() {
		if(get_option('homeland_theme_font')=="Open Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,800,700,600,300&subset=latin,cyrillic-ext,greek-ext,greek,vietnamese,latin-ext,cyrillic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Droid Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Droid+Sans:400,700' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Lato") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Raleway") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,900,800' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="PT Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=PT+Sans:400,700,400italic,700italic&subset=latin,cyrillic-ext,latin-ext,cyrillic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Noto Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic,700italic&subset=latin,cyrillic-ext,greek-ext,greek,vietnamese,latin-ext,cyrillic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Oxygen") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Oxygen:400,300,700&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Source Sans Pro") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic&subset=latin,vietnamese,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Muli") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Muli:300,400,300italic,400italic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Istok Web") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Istok+Web:400,700,400italic,700italic&subset=latin,cyrillic-ext,latin-ext,cyrillic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Puritan") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Puritan:400,700,400italic,700italic' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Gafata") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Gafata&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );
		elseif(get_option('homeland_theme_font')=="Cambo") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Cambo' );
			wp_enqueue_style( 'homeland_custom_font' );	
		elseif(get_option('homeland_theme_font')=="Voces") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Voces&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );	
		elseif(get_option('homeland_theme_font')=="Duru Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Duru+Sans&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );		
		elseif(get_option('homeland_theme_font')=="Sintony") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Sintony:400,700&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );	
		elseif(get_option('homeland_theme_font')=="Carrois Gothic") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Carrois+Gothic' );
			wp_enqueue_style( 'homeland_custom_font' );	
		elseif(get_option('homeland_theme_font')=="Alegreya Sans") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=Alegreya+Sans:100,300,400,500,700,800,900,100italic,300italic,400italic,500italic,700italic,800italic,900italic&subset=latin,vietnamese,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );	
		elseif(get_option('homeland_theme_font')=="News Cycle") : 
			wp_register_style( 'homeland_custom_font', 'http://fonts.googleapis.com/css?family=News+Cycle:400,700&subset=latin,latin-ext' );
			wp_enqueue_style( 'homeland_custom_font' );	
		else :
			wp_register_style( 'homeland_roboto', 'http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic&subset=latin,cyrillic-ext,greek-ext,greek,vietnamese,latin-ext,cyrillic' );
			wp_enqueue_style( 'homeland_roboto' );			
		endif;
	}
	add_action('wp_enqueue_scripts', 'homeland_custom_font_family');


	/**********************************************
	THEME FONT SELECTION IN ACTION
	***********************************************/

	function homeland_custom_font_family_action() {
		if(get_option('homeland_theme_font')=="Open Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Open Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Droid Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Droid Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Lato") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Lato', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Raleway") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Raleway', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="PT Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'PT Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Noto Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Noto Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Oxygen") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Oxygen', sans-serif; }	</style><?php
		elseif(get_option('homeland_theme_font')=="Source Sans Pro") : ?>
			<style type="text/css">	body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Source Sans Pro', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Muli") : ?>
			<style type="text/css">	body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Muli', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Istok Web") : ?>
			<style type="text/css">	body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Istok Web', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Puritan") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Puritan', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Gafata") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Gafata', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Cambo") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Cambo', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Voces") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Voces', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Duru Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Duru Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Sintony") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Sintony', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Carrois Gothic") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Carrois Gothic', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="Alegreya Sans") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Alegreya Sans', sans-serif; } </style><?php
		elseif(get_option('homeland_theme_font')=="News Cycle") : ?>
			<style type="text/css"> body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'News Cycle', sans-serif; } </style><?php
		else : ?>
			<style type="text/css">	body, h1, h2, h3, h4, h5, h6, input, textarea, select, .widget_revslider .tp-caption { font-family:'Roboto', sans-serif; } </style><?php
		endif;
	}
	add_action('wp_head', 'homeland_custom_font_family_action');


	/**********************************************
	GOOGLE ANALYTICS CODE
	***********************************************/

	add_action('wp_footer', 'homeland_google_analytics', 100);
	function homeland_google_analytics() {
		$homeland_ga_code = get_option( 'homeland_ga_code' );

		if(!empty( $homeland_ga_code )) : echo stripslashes( $homeland_ga_code ); endif;
	}

?>