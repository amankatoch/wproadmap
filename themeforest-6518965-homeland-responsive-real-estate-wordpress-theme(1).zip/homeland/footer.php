	<footer>	
		<?php
			if(esc_attr( get_option( 'homeland_hide_widgets' ) ) != "true") :
				?>
				<!--FOOTER WIDGETS-->
				<section class="footer-widgets">
					<div class="inside clear">
						<div class="widget-column">
							<?php
								if ( is_active_sidebar( 'homeland_footer_one' ) ) : dynamic_sidebar( 'homeland_footer_one' );
								else : _e( 'This is a widget area, so please add widgets here...', CODEEX_THEME_NAME );
								endif;
							?>
						</div>
						<div class="widget-column">
							<?php
								if ( is_active_sidebar( 'homeland_footer_two' ) ) : dynamic_sidebar( 'homeland_footer_two' );
								else : _e( 'This is a widget area, so please add widgets here...', CODEEX_THEME_NAME );
								endif;
							?>
						</div>
						<div class="widget-column">
							<?php
								if ( is_active_sidebar( 'homeland_footer_three' ) ) : dynamic_sidebar( 'homeland_footer_three' );
								else : _e( 'This is a widget area, so please add widgets here...', CODEEX_THEME_NAME );
								endif;
							?>
						</div>
						<div class="widget-column last">
							<?php
								if ( is_active_sidebar( 'homeland_footer_four' ) ) : dynamic_sidebar( 'homeland_footer_four' );
								else : _e( 'This is a widget area, so please add widgets here...', CODEEX_THEME_NAME );
								endif;
							?>
						</div>
					</div>
				</section>
				<?php						
			endif;
		?>
		<section class="footer-main">
			<div class="inside clear">
				<div class="footer-inside">
					<label class="copyright">
						<?php 
							echo "&copy;&nbsp;" . date('Y') . "&nbsp;"; ?><a href="<?php echo esc_url( home_url() ); ?>"><?php esc_attr( bloginfo('name') ); ?></a><?php
							echo "&nbsp;&dash;&nbsp;"; echo stripslashes(get_option( 'homeland_copyright_text' )); echo "&nbsp;"; 
						?>
					</label>
					<a href="#" id="toTop"><i class="fa fa-angle-up"></i></a>	
				</div>
			</div>
		</section>			
	</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>